from main import main
import sys

if __name__ == '__main__':
	#print sys.argv[1]
	#start = time()
	main()
	#end = time()
	#print end-start